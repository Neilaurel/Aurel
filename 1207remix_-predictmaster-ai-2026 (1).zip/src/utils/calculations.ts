import * as math from 'mathjs';
import { AnalysisResult, RecentMatch } from '../types';
import { WEIGHTS_6 } from '../constants';

export const recalculateAnalysis = (currentResult: AnalysisResult): AnalysisResult => {
  const getRawScores = (matches: RecentMatch[], type: 'att' | 'def') => {
    if (!matches || matches.length === 0) return [];
    return matches.map(m => type === 'att' ? Number(m.goalsScored) : Number(m.goalsConceded)).filter(s => !isNaN(s));
  };

  const homeAttScores = getRawScores(currentResult.recentMatches?.home || [], 'att');
  const homeDefScores = getRawScores(currentResult.recentMatches?.home || [], 'def');
  const awayAttScores = getRawScores(currentResult.recentMatches?.away || [], 'att');
  const awayDefScores = getRawScores(currentResult.recentMatches?.away || [], 'def');

  const homeTeamName = currentResult?.match?.homeTeam || "Equipe A";
  const awayTeamName = currentResult?.match?.awayTeam || "Equipe B";

  // Merged Ensembles (User Request April 26) - Exactly 12 points
  const homeMergedSet = [...homeAttScores, ...awayDefScores];
  const awayMergedSet = [...awayAttScores, ...homeDefScores];

  const getFCD = (set: number[], threshold: number) => {
    if (!set || !Array.isArray(set) || set.length === 0) return 0;
    const count = set.filter(x => typeof x === 'number' && x >= threshold).length;
    return count / set.length;
  };

  const getMode = (arr: number[]) => {
    if (!arr || !Array.isArray(arr) || arr.length === 0) return 0;
    const counts: Record<number, number> = {};
    arr.forEach(x => {
      if (x !== undefined && x !== null) {
        counts[x] = (counts[x] || 0) + 1;
      }
    });
    let maxCount = 0;
    let mode = arr[0] || 0;
    for (const val in counts) {
      if (counts[val] > maxCount) {
        maxCount = counts[val];
        mode = Number(val);
      }
    }
    return mode;
  };

  // --- SEASON STATS INTEGRATION ---
  let mu_h = homeMergedSet.length > 0 ? math.number(math.mean(homeMergedSet)) as number : 0;
  let mu_a = awayMergedSet.length > 0 ? math.number(math.mean(awayMergedSet)) as number : 0;
  let var_h = homeMergedSet.length > 0 ? math.number(math.variance(homeMergedSet)) as number : 0;
  let var_a = awayMergedSet.length > 0 ? math.number(math.variance(awayMergedSet)) as number : 0;

  // Prioritize Season Stats from Tournament Tables if available
  if (currentResult.standings) {
    const sH = currentResult.standings.home;
    const sA = currentResult.standings.away;

    if (sH && sH.played > 0 && sH.gf_home !== undefined && sH.ga_home !== undefined) {
      // Use home-specific season stats for home team
      const season_mu_h = sH.gf_home / (sH.played / 2); // Approximation of games at home
      mu_h = (mu_h * 0.4) + (season_mu_h * 0.6); // Weighted blend
      if (sH.season_variance) var_h = sH.season_variance;
    }
    if (sA && sA.played > 0 && sA.gf_away !== undefined && sA.ga_away !== undefined) {
      // Use away-specific season stats for away team
      const season_mu_a = sA.gf_away / (sA.played / 2);
      mu_a = (mu_a * 0.4) + (season_mu_a * 0.6);
      if (sA.season_variance) var_a = sA.season_variance;
    }
  }

  // --- QUALITATIVE ADJUSTMENT ---
  if (currentResult.quantitativeData?.qualScore) {
    const impactH = currentResult.quantitativeData.qualScore.impactHome ?? 1.0;
    const impactA = currentResult.quantitativeData.qualScore.impactAway ?? 1.0;
    mu_h *= impactH;
    mu_a *= impactA;
  }

  // --- NEW CALCULATION METHOD (Scorers & Defense) ---
  if (currentResult.quantitativeData?.topScorersStats && currentResult.quantitativeData?.defenseCapacity) {
    const { homeConcededAvg, awayConcededAvg } = currentResult.quantitativeData.defenseCapacity;
    const { homeScorers, awayScorers } = currentResult.quantitativeData.topScorersStats;

    // 1. Defense Adjustment (based on conceded goals)
    const homeDefFactor = awayConcededAvg / (homeConcededAvg || 1);
    const awayDefFactor = homeConcededAvg / (awayConcededAvg || 1);

    // 2. Scorer Adjustment (rough proxy based on scorer count - could be improved with actual goals, but this uses top 3)
    const homeScorerBonus = homeScorers.length * 0.05; 
    const awayScorerBonus = awayScorers.length * 0.05;

    // Cross-team adjustment combining defense and scorers
    mu_h *= (1 + (homeDefFactor - 1) * 0.05 + homeScorerBonus);
    mu_a *= (1 + (awayDefFactor - 1) * 0.05 + awayScorerBonus);
  }

  const median_h = homeMergedSet.length > 0 ? math.number(math.median(homeMergedSet)) as number : 0;
  const median_a = awayMergedSet.length > 0 ? math.number(math.median(awayMergedSet)) as number : 0;
  const mode_h = getMode(homeMergedSet);
  const mode_a = getMode(awayMergedSet);

  // FCD calculations on the ensemble (12 real values)
  const fcd_mu_h = getFCD(homeMergedSet, mu_h);
  const fcd_med_h = getFCD(homeMergedSet, median_h);
  const fcd_mode_h = getFCD(homeMergedSet, mode_h);

  const fcd_mu_a = getFCD(awayMergedSet, mu_a);
  const fcd_med_a = getFCD(awayMergedSet, median_a);
  const fcd_mode_a = getFCD(awayMergedSet, mode_a);

  const alpha_h = var_h > mu_h && mu_h > 0 ? (var_h - mu_h) / Math.pow(mu_h, 2) : 0;
  const alpha_a = var_a > mu_a && mu_a > 0 ? (var_a - mu_a) / Math.pow(mu_a, 2) : 0;

  const getProb = (k: number, mu: number, alpha: number) => {
    if (mu <= 0) return k === 0 ? 1 : 0;
    if (alpha <= 0) {
      // Poisson using logs: P(X=k) = exp(k*ln(mu) - mu - ln(k!))
      const logProb = k * Math.log(mu) - mu - (math.lgamma(k + 1) as any as number);
      return Math.exp(logProb);
    } else {
      // Negative Binomial NB2 using logs
      // P(X=k) = [Gamma(k+n) / (k! * Gamma(n))] * p^n * (1-p)^k
      // n = 1/alpha, p = n/(n+mu)
      const n = 1 / alpha;
      const p = n / (n + mu);
      try {
        const logGammaKn = (math.lgamma(k + n) as any as number);
        const logGammaN = (math.lgamma(n) as any as number);
        const logFactK = (math.lgamma(k + 1) as any as number);
        
        const logCoeff = logGammaKn - (logFactK + logGammaN);
        const logProb = logCoeff + n * Math.log(p) + k * Math.log(1 - p);
        return Math.exp(logProb);
      } catch (e) {
        // Fallback to simple Poisson log if gamma fails
        const logProb = k * Math.log(mu) - mu - (math.lgamma(k + 1) as any as number);
        return Math.exp(logProb);
      }
    }
  };

  const tol = currentResult.sport === 'basketball' ? 5 : 1;

  if (currentResult.sport === 'basketball') {
    const pointsRange = Array.from({ length: 141 }, (_, i) => i + 60); // 60 to 200
    const homePmf = pointsRange.map(k => getProb(k, mu_h, alpha_h));
    const awayPmf = pointsRange.map(k => getProb(k, mu_a, alpha_a));

    // Basketball IFR: [mu-10, mu-5, mu, mu+5, mu+10]
    const fcd_m10_h = getFCD(homeMergedSet, mu_h - 10);
    const fcd_m5_h = getFCD(homeMergedSet, mu_h - 5);
    const fcd_p5_h = getFCD(homeMergedSet, mu_h + 5);
    const fcd_p10_h = getFCD(homeMergedSet, mu_h + 10);

    const fcd_m10_a = getFCD(awayMergedSet, mu_a - 10);
    const fcd_m5_a = getFCD(awayMergedSet, mu_a - 5);
    const fcd_p5_a = getFCD(awayMergedSet, mu_a + 5);
    const fcd_p10_a = getFCD(awayMergedSet, mu_a + 10);

    const margins = {
      "Victoire Home 1-5": 0,
      "Victoire Home 6-10": 0,
      "Victoire Home 11-15": 0,
      "Victoire Home 16+": 0,
      "Victoire Away 1-5": 0,
      "Victoire Away 6-10": 0,
      "Victoire Away 11-15": 0,
      "Victoire Away 16+": 0
    };

    let pHome = 0, pDraw = 0, pAway = 0;
    let maxProb = -1, bestH = 0, bestA = 0;

    for (let i = 0; i < pointsRange.length; i++) {
      for (let j = 0; j < pointsRange.length; j++) {
        const prob = homePmf[i] * awayPmf[j];
        const ph = pointsRange[i];
        const pa = pointsRange[j];
        const diff = ph - pa;

        if (ph > pa) pHome += prob;
        else if (ph === pa) pDraw += prob;
        else pAway += prob;

        if (diff >= 1 && diff <= 5) margins["Victoire Home 1-5"] += prob;
        else if (diff >= 6 && diff <= 10) margins["Victoire Home 6-10"] += prob;
        else if (diff >= 11 && diff <= 15) margins["Victoire Home 11-15"] += prob;
        else if (diff >= 16) margins["Victoire Home 16+"] += prob;
        else if (diff >= -5 && diff <= -1) margins["Victoire Away 1-5"] += prob;
        else if (diff >= -10 && diff <= -6) margins["Victoire Away 6-10"] += prob;
        else if (diff >= -15 && diff <= -11) margins["Victoire Away 11-15"] += prob;
        else if (diff <= -16) margins["Victoire Away 16+"] += prob;

        if (prob > maxProb) {
          maxProb = prob;
          bestH = ph;
          bestA = pa;
        }
      }
    }

    const steps = `MOTEUR PRÉDICTMASTER AI BASKETBALL (NB2)
----------------------------------
1. ENSEMBLES FUSIONNÉS (Score Cible + Déf Adverse):
   🏠 ${homeTeamName}: mu=${mu_h.toFixed(1)} Med=${median_h} Mode=${mode_h}
   🚀 ${awayTeamName}: mu=${mu_a.toFixed(1)} Med=${median_a} Mode=${mode_a}
2. INDICE FIABILITÉ RÉELLE (IFR) [P>=val]:
   🏠 Home: mu=${(fcd_mu_h*100).toFixed(1)}% | Med=${(fcd_med_h*100).toFixed(1)}% | Mode=${(fcd_mode_h*100).toFixed(1)}%
   🚀 Away: mu=${(fcd_mu_a*100).toFixed(1)}% | Med=${(fcd_med_a*100).toFixed(1)}% | Mode=${(fcd_mode_a*100).toFixed(1)}%
3. IFR BASKET (Intervalle mu):
   🏠 Home: ${mu_h-10}: ${(fcd_m10_h*100).toFixed(0)}% | ${mu_h-5}: ${(fcd_m5_h*100).toFixed(0)}% | ${mu_h+5}: ${(fcd_p5_h*100).toFixed(0)}%
   🚀 Away: ${mu_a-10}: ${(fcd_m10_a*100).toFixed(0)}% | ${mu_a-5}: ${(fcd_m5_a*100).toFixed(0)}% | ${mu_a+5}: ${(fcd_p5_a*100).toFixed(0)}%
4. PRÉDICTION: ${bestH}-${bestA} (${(maxProb * 100).toFixed(2)}%)`;

    return {
      ...currentResult,
      probabilities: { home: pHome, draw: pDraw, away: pAway, over25: 1, btts: 1 },
      fairOdds: { home: pHome > 0 ? 1/pHome : 0, draw: pDraw > 0 ? 1/pDraw : 0, away: pAway > 0 ? 1/pAway : 0 },
      scoreExact: { home: bestH, away: bestA, probability: maxProb * 100 },
      basketballMargins: margins,
      quantitativeData: {
        ...currentResult.quantitativeData!,
        homeModel: 'NegBin',
        awayModel: 'NegBin',
        homeLambdaFinal: mu_h,
        awayLambdaFinal: mu_a,
        homeMedianFinal: median_h,
        awayMedianFinal: median_a,
        homeModeFinal: mode_h,
        awayModeFinal: mode_a,
        homeProbAboveMean: fcd_mu_h,
        awayProbAboveMean: fcd_mu_a,
        homeProbAboveMedian: fcd_med_h,
        awayProbAboveMedian: fcd_med_a,
        homeProbAboveMode: fcd_mode_h,
        awayProbAboveMode: fcd_mode_a,
        homeProbAboveM10: fcd_m10_h,
        homeProbAboveM5: fcd_m5_h,
        homeProbAboveP5: fcd_p5_h,
        homeProbAboveP10: fcd_p10_h,
        awayProbAboveM10: fcd_m10_a,
        awayProbAboveM5: fcd_m5_a,
        awayProbAboveP5: fcd_p5_a,
        awayProbAboveP10: fcd_p10_a,
        homeVariance: var_h,
        awayVariance: var_a,
        calculationSteps: steps
      }
    };
  }

  const matrix: number[][] = Array(9).fill(0).map(() => Array(9).fill(0));
  let hAbove = 0, hRange = 0, hAboveMedian = 0, hAboveMode = 0;
  let aAbove = 0, aRange = 0, aAboveMedian = 0, aAboveMode = 0;
  
  // High precision PMF calculation for indicators (up to 15 goals for tails)
  const homePmfLong = Array.from({length: 16}, (_, k) => getProb(k, mu_h, alpha_h));
  const awayPmfLong = Array.from({length: 16}, (_, k) => getProb(k, mu_a, alpha_a));
  
  homePmfLong.forEach((p, k) => {
    if (k >= mu_h) hAbove += p;
    if (k >= median_h) hAboveMedian += p;
    if (k >= mode_h) hAboveMode += p;
    if (k >= mu_h - tol && k <= mu_h + tol) hRange += p;
  });
  awayPmfLong.forEach((p, k) => {
    if (k >= mu_a) aAbove += p;
    if (k >= median_a) aAboveMedian += p;
    if (k >= mode_a) aAboveMode += p;
    if (k >= mu_a - tol && k <= mu_a + tol) aRange += p;
  });

  for (let i = 0; i < 9; i++) {
    for (let j = 0; j < 9; j++) {
      matrix[i][j] = homePmfLong[i] * awayPmfLong[j];
    }
  }

  // Normalization
  const sumMatrix = matrix.reduce((acc, row) => acc + row.reduce((a, b) => a + b, 0), 0);
  if (sumMatrix > 0) {
    for (let i = 0; i < 9; i++) {
      for (let j = 0; j < 9; j++) {
        matrix[i][j] /= sumMatrix;
      }
    }
  }

  let pHome = 0, pDraw = 0, pAway = 0, over25 = 0, btts = 0;
  let maxProb = -1, bestH = 0, bestA = 0;

  for (let i = 0; i < 9; i++) {
    for (let j = 0; j < 9; j++) {
      const prob = matrix[i][j];
      if (i > j) pHome += prob;
      else if (i === j) pDraw += prob;
      else pAway += prob;

      if (i + j > 2.5) over25 += prob;
      if (i > 0 && j > 0) btts += prob;

      if (prob > maxProb) {
        maxProb = prob;
        bestH = i;
        bestA = j;
      }
    }
  }

  const impactH = currentResult.quantitativeData?.qualScore?.impactHome ?? 1.0;
  const impactA = currentResult.quantitativeData?.qualScore?.impactAway ?? 1.0;

  const steps = `MOTEUR PRÉDICTMASTER AI FOOTBALL (V4.5 NEG-BIN)
----------------------------------
1. STATS SAISON & FUSION (Ajusté):
   🏠 ${homeTeamName}: λ=${mu_h?.toFixed(3)} (Impact Q: ${((impactH-1)*100).toFixed(0)}%)
   🚀 ${awayTeamName}: λ=${mu_a?.toFixed(3)} (Impact Q: ${((impactA-1)*100).toFixed(0)}%)
2. INDICE FIABILITÉ RÉELLE (IFR) [P>=val]:
   🏠 Home: mu=${(fcd_mu_h*100).toFixed(1)}% | Med=${(fcd_med_h*100).toFixed(1)}% | Mode=${(fcd_mode_h*100).toFixed(1)}%
   🚀 Away: mu=${(fcd_mu_a*100).toFixed(1)}% | Med=${(fcd_med_a*100).toFixed(1)}% | Mode=${(fcd_mode_a*100).toFixed(1)}%
3. VARIANCES & DISPERSION (r/p):
   🏠 σ²=${var_h?.toFixed(3)} (α=${alpha_h?.toFixed(3)})
   🚀 σ²=${var_a?.toFixed(3)} (α=${alpha_a?.toFixed(3)})
4. MODÈLES UTILISÉS:
   🏠 ${alpha_h <= 0 ? 'Poisson' : 'NegBin'} | 🚀 ${alpha_a <= 0 ? 'Poisson' : 'NegBin'}
5. PRÉDICTION: ${bestH}-${bestA} (${(maxProb * 100)?.toFixed(1)}%)`;

  return {
    ...currentResult,
    probabilities: { home: pHome, draw: pDraw, away: pAway, over25, btts },
    fairOdds: { home: pHome > 0 ? 1/pHome : 0, draw: pDraw > 0 ? 1/pDraw : 0, away: pAway > 0 ? 1/pAway : 0 },
    scoreExact: { home: bestH, away: bestA, probability: maxProb * 100 },
    scoreMatrix: matrix.map(row => row.map(v => v * 100)),
    quantitativeData: {
      ...currentResult.quantitativeData!,
      homeModel: (alpha_h === 0 ? 'Poisson' : 'NegBin') as any,
      awayModel: (alpha_a === 0 ? 'Poisson' : 'NegBin') as any,
      homeLambdaFinal: mu_h,
      awayLambdaFinal: mu_a,
      homeMedianFinal: median_h,
      awayMedianFinal: median_a,
      homeModeFinal: mode_h,
      awayModeFinal: mode_a,
      homeProbAboveMean: fcd_mu_h,
      awayProbAboveMean: fcd_mu_a,
      homeProbAboveMedian: fcd_med_h,
      awayProbAboveMedian: fcd_med_a,
      homeProbAboveMode: fcd_mode_h,
      awayProbAboveMode: fcd_mode_a,
      homeProbInRange: hRange,
      awayProbInRange: aRange,
      homeVariance: var_h,
      awayVariance: var_a,
      calculationSteps: steps,
      metricFormulas: {
        homeLambdaFinal: 'mean(home_goals) + mean(away_conceded)',
        awayLambdaFinal: 'mean(away_goals) + mean(home_conceded)',
      }
    }
  };
};
