/**
 * Types globaux pour PredictMaster AI 2026
 */

export type Sport = 'football' | 'basketball';
export type View = 'analyze' | 'history' | 'bankroll' | 'settings' | 'coupon' | 'live' | 'explorer' | 'course' | 'logs' | 'firecrawl';
export type RiskProfile = 'conservative' | 'balanced' | 'aggressive';

export interface MatchInfo {
  homeTeam: string;
  awayTeam: string;
  date: string;
  timestamp: number;
  competition: string;
  odds: {
    home: number;
    draw?: number;
    away: number;
    [key: string]: any;
  };
}

export interface Prediction {
  id: string;
  matchName: string;
  sport: Sport;
  type: string;
  odd: number;
  confidence: number;
  reasoning: string;
  isValueBet?: boolean;
  edge?: number;
}

export interface ExpertOpinion {
  source: string;
  opinion: string;
  confidence: string;
}

export interface RecentMatch {
  date: string;
  opponent: string;
  score: string;
  goalsScored: number;
  goalsConceded: number;
  result: 'W' | 'D' | 'L';
  isHome: boolean;
  timestamp?: number;
}

export interface LogStep {
  time: string;
  action: string;
  details?: string;
  type: 'info' | 'error' | 'decision' | 'ai_reasoning' | 'warning';
}

export interface AnalysisLog {
  id: string;
  timestamp: number;
  matchName: string;
  steps: LogStep[];
}

export interface AnalysisResult {
  id: string;
  timestamp: number;
  userId?: string;
  sport: Sport;
  match: MatchInfo;
  predictions: Prediction[];
  expertOpinions: ExpertOpinion[];
  formAnalysis: string;
  h2hAnalysis: string;
  absencesAnalysis: string;
  playerAnalysis: string;
  summary: string;
  scoreExact?: { home: number; away: number; probability: number };
  fairOdds?: { home: number; draw: number; away: number };
  probabilities?: {
    home: number;
    draw: number;
    away: number;
    over25: number;
    btts: number;
  };
  leverage?: { home: number; away: number };
  weather?: { condition: string; temp: number; impact: string };
  referee?: { name: string; cardsPerMatch: number; impact: string };
  sources?: { name: string; url: string }[];
  recentMatches?: {
    home: RecentMatch[];
    away: RecentMatch[];
  };
  scoreMatrix?: number[][] | string;
  quantitativeData?: {
    halfTimeStats?: { homeHT: string; awayHT: string; };
    topScorersStats?: { homeScorers: string[]; awayScorers: string[]; };
    defenseCapacity?: { homeConcededAvg: number; awayConcededAvg: number; };
    homeModel: 'Poisson' | 'NegBin';
    awayModel: 'Poisson' | 'NegBin';
    homeLambdaAtt: number;
    homeLambdaDef: number;
    awayLambdaAtt: number;
    awayLambdaDef: number;
    homeLambdaFinal: number;
    awayLambdaFinal: number;
    homeMedianFinal?: number;
    awayMedianFinal?: number;
    homeModeFinal?: number;
    awayModeFinal?: number;
    homeProbAboveMean?: number;
    homeProbAboveMedian?: number;
    homeProbAboveMode?: number;
    homeProbAboveM10?: number;
    homeProbAboveM5?: number;
    homeProbAboveP5?: number;
    homeProbAboveP10?: number;
    awayProbAboveMean?: number;
    awayProbAboveMedian?: number;
    awayProbAboveMode?: number;
    awayProbAboveM10?: number;
    awayProbAboveM5?: number;
    awayProbAboveP5?: number;
    awayProbAboveP10?: number;
    homeProbInRange?: number;
    awayProbInRange?: number;
    homeVariance: number;
    awayVariance: number;
    homeR: number | null;
    awayR: number | null;
    h2hApplied: boolean;
    dcApplied: boolean;
    weightedScores: {
      home: number[];
      away: number[];
      weights: number[];
    };
    qualScore: {
      home: number;
      away: number;
      verdict: string;
      impactHome?: number; // % adjustment (e.g. 0.9 for -10% if key player missing)
      impactAway?: number;
    };
    notes: string;
    calculationSteps?: string;
      metricFormulas?: { [key: string]: string };
    };
  qualitativePredictions?: Prediction[];
  h2hMatches?: { date: string; home: string; away: string; score: string; goalsHome: number; goalsAway: number; competition?: string; timestamp?: number }[];
  basketballMargins?: {
    [key: string]: number;
  };
  standings?: {
    home: { 
      rank: number; 
      points: number; 
      played: number; 
      gf_total?: number; 
      ga_total?: number; 
      gf_home?: number; 
      ga_home?: number;
      season_variance?: number;
      alert: string | null 
    };
    away: { 
      rank: number; 
      points: number; 
      played: number; 
      gf_total?: number; 
      ga_total?: number; 
      gf_away?: number; 
      ga_away?: number;
      season_variance?: number;
      alert: string | null 
    };
  };
  qualitative?: {
    absences: string;
    momentum: string;
    referee: string;
    filtersIntelligence?: {
      trapGame: string;
      paceStyle: string;
      meteoTerrain: string;
      climatSocial: string;
    };
    contreExpertise: {
      alerteContradiction: string;
      impactEffectif: string;
      facteurMotivation: string;
      fatigueVoyage: string;
      verdictFinalQuali: string;
    };
  };
  marketSelection?: {
    market: string;
    priority: string;
    readability: number;
    risk: string;
    reasoning: string;
  }[];
  isBatch?: boolean;
  batchIds?: string[]; // IDs of individual match analyses in this batch
  comboReport?: string;
  report?: string;
  spreadsheetId?: string;
  spreadsheetUrl?: string;
  debugPrompts?: {
    collector: string;
    analyzer: string;
    report: string;
  };
}

export interface CouponItem {
  prediction: Prediction;
  match: MatchInfo;
}

export interface Bet {
  id: string;
  userId?: string;
  matchId: string;
  matchName: string;
  prediction: string;
  odd: number;
  stake: number;
  status: 'pending' | 'won' | 'lost';
  score?: string;
  timestamp: number;
  sport: Sport;
  isCombined?: boolean;
}

export interface BalanceSnapshot {
  timestamp: number;
  balance: number;
}

export interface Bankroll {
  balance: number;
  initialBalance: number;
  lockedBalance: number;
  currency: string;
  savingsGoal: number;
  dailyTargetOdd: number;
  maxTicketsPerDay: number;
  maxEventsPerCoupon: number;
  minConfidence: number;
  riskProfile: RiskProfile;
  adaptiveMode: boolean;
  balanceHistory: BalanceSnapshot[];
}
